//
//  DetailViewController.swift
//  WRG_Task
//
//  Created by Vinothkumar.v02 on 27/05/22.
//

import UIKit
import CoreData

class DetailViewController: UIViewController {
    
    var selectedEmployeeID = ""
    
    
    var profile_Image:String = ""
    var name:String = ""
    var userName:String = ""
    var email:String = ""
    var address:String = ""
    var phone:String = ""
    var website:String = ""
    var company:String = ""
    
    
    lazy var backgroundView: UIView = {
        let view = UIView()
        view.backgroundColor = #colorLiteral(red: 0.2605174184, green: 0.2605243921, blue: 0.260520637, alpha: 1)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var profileImage: UIImageView = {
        let img = UIImageView()
        img.layer.cornerRadius = 50
        img.clipsToBounds = true
        img.translatesAutoresizingMaskIntoConstraints = false
        return img
    }()
    
    lazy var namelbl: UILabel = {
        let lbl = UILabel()
        lbl.textAlignment = .left
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.textColor = .white
        return lbl
    }()
    
    lazy var userNamelbl: UILabel = {
        let lbl = UILabel()
        lbl.textAlignment = .left
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.textColor = .white
        return lbl
    }()
    
    lazy var emaillbl: UILabel = {
        let lbl = UILabel()
        lbl.textAlignment = .left
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.textColor = .white
        return lbl
    }()
    
    lazy var addresslbl: UILabel = {
        let lbl = UILabel()
        lbl.textAlignment = .left
        lbl.numberOfLines = 0
        lbl.lineBreakMode = .byWordWrapping
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.textColor = .white
        return lbl
    }()
    
    lazy var phonelbl: UILabel = {
        let lbl = UILabel()
        lbl.textAlignment = .left
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.textColor = .white
        return lbl
    }()
    
    lazy var websitelbl: UILabel = {
        let lbl = UILabel()
        lbl.textAlignment = .left
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.textColor = .white
        return lbl
    }()
    
    
    
    lazy var comapnyNamelbl: UILabel = {
        let lbl = UILabel()
        lbl.textAlignment = .left
        lbl.numberOfLines = 0
        lbl.lineBreakMode = .byWordWrapping
        lbl.font = UIFont.boldSystemFont(ofSize: 18)
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.textColor = #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)
        return lbl
    }()
    
    
    
    func setupViews() {
        
        self.view.addSubview(backgroundView)
        backgroundView.leftAnchor.constraint(equalTo: self.view.leftAnchor).isActive = true
        backgroundView.rightAnchor.constraint(equalTo: self.view.rightAnchor).isActive = true
        backgroundView.topAnchor.constraint(equalTo: self.view.topAnchor,constant: 100).isActive = true
        backgroundView.bottomAnchor.constraint(equalTo: self.view.bottomAnchor).isActive = true
        
        backgroundView.addSubview(profileImage)
        profileImage.leftAnchor.constraint(equalTo: backgroundView.leftAnchor, constant: 10).isActive = true
        profileImage.topAnchor.constraint(equalTo: backgroundView.topAnchor,constant: 20).isActive = true
        profileImage.heightAnchor.constraint(equalToConstant: 100).isActive = true
        profileImage.widthAnchor.constraint(equalToConstant: 100).isActive = true
        
        
        backgroundView.addSubview(userNamelbl)
        userNamelbl.leftAnchor.constraint(equalTo: profileImage.rightAnchor, constant: 10).isActive = true
        userNamelbl.rightAnchor.constraint(equalTo: backgroundView.rightAnchor, constant: -5).isActive = true
        userNamelbl.topAnchor.constraint(equalTo: backgroundView.topAnchor,constant: 20).isActive = true
        userNamelbl.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
        
        backgroundView.addSubview(emaillbl)
        emaillbl.leftAnchor.constraint(equalTo: profileImage.rightAnchor, constant: 10).isActive = true
        emaillbl.rightAnchor.constraint(equalTo: backgroundView.rightAnchor, constant: -5).isActive = true
        emaillbl.topAnchor.constraint(equalTo: userNamelbl.bottomAnchor,constant: 1).isActive = true
        emaillbl.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
        
        backgroundView.addSubview(phonelbl)
        phonelbl.leftAnchor.constraint(equalTo: profileImage.rightAnchor, constant: 10).isActive = true
        phonelbl.rightAnchor.constraint(equalTo: backgroundView.rightAnchor, constant: -5).isActive = true
        phonelbl.topAnchor.constraint(equalTo: emaillbl.bottomAnchor,constant: 1).isActive = true
        phonelbl.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
        backgroundView.addSubview(websitelbl)
        websitelbl.leftAnchor.constraint(equalTo: profileImage.rightAnchor, constant: 10).isActive = true
        websitelbl.rightAnchor.constraint(equalTo: backgroundView.rightAnchor, constant: -5).isActive = true
        websitelbl.topAnchor.constraint(equalTo: phonelbl.bottomAnchor,constant: 1).isActive = true
        websitelbl.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
        backgroundView.addSubview(addresslbl)
        addresslbl.leftAnchor.constraint(equalTo: backgroundView.leftAnchor, constant: 20).isActive = true
        addresslbl.rightAnchor.constraint(equalTo: backgroundView.rightAnchor, constant: -5).isActive = true
        addresslbl.topAnchor.constraint(equalTo: profileImage.bottomAnchor,constant: 20).isActive = true
        addresslbl.heightAnchor.constraint(equalToConstant: 100).isActive = true
        
        
        backgroundView.addSubview(comapnyNamelbl)
        comapnyNamelbl.leftAnchor.constraint(equalTo: backgroundView.leftAnchor, constant: 20).isActive = true
        comapnyNamelbl.rightAnchor.constraint(equalTo: backgroundView.rightAnchor, constant: -5).isActive = true
        comapnyNamelbl.topAnchor.constraint(equalTo: addresslbl.bottomAnchor,constant: 1).isActive = true
        comapnyNamelbl.heightAnchor.constraint(equalToConstant: 100).isActive = true
        
        
        
    }
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = name.capitalized
        
        setupViews()
        
        address = userSelectedAddress(identifier: selectedEmployeeID)
        company = userSelectedCompany(identifier: selectedEmployeeID)
        
        profileImage.sd_setImage(with: URL(string: profile_Image), placeholderImage: UIImage.init(named: "Profile"))
        namelbl.text = name
        userNamelbl.text = userName
        emaillbl.text = email
        phonelbl.text = phone
        websitelbl.text = website
        addresslbl.text =  (address.isEmpty) ? address : ("Address:\n\n" + address)
        comapnyNamelbl.text = company.isEmpty ? company : "Company:\n\n" + company
        
        // Do any additional setup after loading the view.
    }
    
    
    
    
    func userSelectedCompany(identifier: String)-> String {
        
        let context = PersistenceService.context
        
        do {
            let fetchRequest : NSFetchRequest<Company> = Company.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "id == %@", identifier)
            let fetchedResults = try context.fetch(fetchRequest)
            if let company = fetchedResults.first {
                if let name = company.name as? String,
                   let catchPhrase = company.catchPhrase as? String,
                   let bs = company.bs as? String{
                    
                    return name + "," + catchPhrase + "," + bs + "."
                }
                return ""
            } else {
                return ""
            }
        }
        catch {
            print ("fetch task failed", error)
        }
        return ""
    }
    
    func userSelectedAddress(identifier: String)-> String {
        
        let context = PersistenceService.context
        
        do {
            let fetchRequest : NSFetchRequest<Address> = Address.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "id == %@", identifier)
            let fetchedResults = try context.fetch(fetchRequest)
            if let address = fetchedResults.first {
                
                if let street = address.street,
                   let suite = address.suite,
                   let city = address.city,
                   let zipcode = address.zipcode {
                    
                    return street + "," + suite + "," + city + "," + zipcode + "."
                }
                return ""
            } else {
                return ""
            }
        }
        catch {
            print ("fetch task failed", error)
        }
        return ""
    }
    
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}
