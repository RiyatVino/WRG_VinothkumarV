//
//  EmployeeListTableViewCell.swift
//  WRG_Vinoth
//
//  Created by Vinothkumar.v02 on 27/05/22.
//

import UIKit

class EmployeeListTableViewCell: UITableViewCell {

    
    lazy var backView: UIView = {
        let view = UIView()
        view.backgroundColor = #colorLiteral(red: 0.2605174184, green: 0.2605243921, blue: 0.260520637, alpha: 1)
        view.translatesAutoresizingMaskIntoConstraints = false
        return view
    }()
    
    lazy var comapnyNamelbl: UILabel = {
        let lbl = UILabel()
        lbl.textAlignment = .left
        lbl.font = UIFont.boldSystemFont(ofSize: 18)
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.textColor = #colorLiteral(red: 0.8078431487, green: 0.02745098062, blue: 0.3333333433, alpha: 1)
        return lbl
    }()
    
    lazy var namelbl: UILabel = {
        let lbl = UILabel()
        lbl.textAlignment = .left
        lbl.translatesAutoresizingMaskIntoConstraints = false
        lbl.textColor = .white
        return lbl
    }()
    
    lazy var profileImage: UIImageView = {
        let img = UIImageView()
        img.layer.cornerRadius = 50
        img.clipsToBounds = true
        img.translatesAutoresizingMaskIntoConstraints = false
        return img
    }()
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        
        addSubview(backView)
        backView.leftAnchor.constraint(equalTo: leftAnchor, constant: 10).isActive = true
        backView.rightAnchor.constraint(equalTo: rightAnchor, constant: -10).isActive = true
        backView.topAnchor.constraint(equalTo: topAnchor,constant: 1).isActive = true
        backView.bottomAnchor.constraint(equalTo: bottomAnchor,constant: -1).isActive = true
        
        backView.addSubview(namelbl)
        backView.addSubview(comapnyNamelbl)
        backView.addSubview(profileImage)
        
        profileImage.leftAnchor.constraint(equalTo: backView.leftAnchor, constant: 5).isActive = true
        profileImage.topAnchor.constraint(equalTo: backView.topAnchor,constant: 5).isActive = true
        profileImage.bottomAnchor.constraint(equalTo: backView.bottomAnchor,constant: -5).isActive = true
        profileImage.widthAnchor.constraint(equalToConstant: 100).isActive = true

        
        namelbl.leftAnchor.constraint(equalTo: profileImage.rightAnchor, constant: 8).isActive = true
        namelbl.rightAnchor.constraint(equalTo: backView.rightAnchor, constant: -8).isActive = true
        namelbl.topAnchor.constraint(equalTo: backView.topAnchor,constant: 5).isActive = true
        namelbl.heightAnchor.constraint(equalToConstant: 20).isActive = true
        
        
        comapnyNamelbl.leftAnchor.constraint(equalTo: profileImage.rightAnchor, constant: 8).isActive = true
        comapnyNamelbl.rightAnchor.constraint(equalTo: backView.rightAnchor, constant: -8).isActive = true
        comapnyNamelbl.topAnchor.constraint(equalTo: namelbl.bottomAnchor,constant: 5).isActive = true
        comapnyNamelbl.heightAnchor.constraint(equalToConstant: 30).isActive = true
        
        
     
        
        // Configure the view for the selected state
    }
    
    override func layoutSubviews() {
        contentView.backgroundColor = UIColor.clear
        backgroundColor = UIColor.clear
        backView.layer.cornerRadius = 5
        backView.clipsToBounds = true
    }
    
  
}
