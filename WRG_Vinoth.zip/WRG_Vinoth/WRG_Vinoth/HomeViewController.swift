//
//  HomeViewController.swift
//  WRG_Task
//
//  Created by Vinothkumar.v02 on 27/05/22.
//

import UIKit
import CoreData
import SDWebImage

class HomeViewController: UIViewController, UISearchBarDelegate {
    
    var employeeList = [Employee]()
    var searchedEmployee = [Employee]()
    var searching = false
    var companyName = ""
    var selectedEmployeeID = ""
    
    var tableView = UITableView()
    lazy var searchBar:UISearchBar = UISearchBar()
    
    func setTableView() {
        tableView.frame = self.view.frame
        tableView.delegate = self
        tableView.dataSource = self
        tableView.separatorColor = UIColor.clear
        tableView.backgroundColor =  .white
        
        self.view.addSubview(tableView)
        
        tableView.register(EmployeeListTableViewCell.self, forCellReuseIdentifier: "Cell")
    }
    
    @objc func refreshData(){
        resetAllCoreData()
        if employeeList.count == 0 {
            self.callAPI()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setTableView()
        retriveData()
        
        searchBar.searchBarStyle = UISearchBar.Style.default
        searchBar.placeholder = " Search..."
        searchBar.sizeToFit()
        searchBar.isTranslucent = false
        searchBar.backgroundImage = UIImage()
        searchBar.delegate = self
        navigationItem.titleView = searchBar
        
        self.title = "Employee's List"
        let refreshBarButtonItem = UIBarButtonItem(title: "Refresh", style: .done, target: self, action: #selector(refreshData))
        self.navigationItem.rightBarButtonItem  = refreshBarButtonItem
        
    }
    
    func searchBar(_ searchBar: UISearchBar, textDidChange textSearched: String)
    {
        searchedEmployee = employeeList.filter { ($0.name?.lowercased().prefix(textSearched.count))! == textSearched.lowercased() || ($0.email?.lowercased().prefix(textSearched.count))! == textSearched.lowercased()  }
        searching = true
        
        tableView.reloadData()
        
    }
    
    func searchBarCancelButtonClicked(searchBar: UISearchBar) {
        
        searching = false
        searchBar.text = nil
        searchBar.resignFirstResponder()
        tableView.reloadData()
    }
    
    
    private func createEmployeeEntityFrom(dictionary: [String: AnyObject]) -> NSManagedObject? {
        let context = PersistenceService.context
        if let employeeEntity = NSEntityDescription.insertNewObject(forEntityName: "Employee", into: context) as? Employee {
            employeeEntity.id = dictionary["id"] as! Int16
            employeeEntity.name = dictionary["name"] as? String
            employeeEntity.username = dictionary["username"] as? String
            employeeEntity.email = dictionary["email"] as? String
            employeeEntity.phone = dictionary["phone"] as? String
            employeeEntity.website = dictionary["website"] as? String
            employeeEntity.profile_image = dictionary["profile_image"] as? String
            
            if let addressEntity = NSEntityDescription.insertNewObject(forEntityName: "Address", into: context) as? Address {
                if let addressData = dictionary["address"] as? [String: AnyObject] {
                    
                    addressEntity.city = addressData["city"] as? String
                    addressEntity.street = addressData["street"] as? String
                    addressEntity.suite = addressData["suite"] as? String
                    addressEntity.zipcode = addressData["zipcode"] as? String
                    addressEntity.id =  dictionary["id"] as! Int16
                    
                    if let geoEntity = NSEntityDescription.insertNewObject(forEntityName: "Geo", into: context) as? Geo {
                        if let geoData = addressData["geo"] as? [String: AnyObject] {
                            
                            geoEntity.lat = geoData["lat"] as? String
                            geoEntity.lng = geoData["lng"] as? String
                        }
                    }
                }
            }
            
            if let companyEntity = NSEntityDescription.insertNewObject(forEntityName: "Company", into: context) as? Company {
                if let companyData = dictionary["company"] as? [String: AnyObject] {
                    
                    companyEntity.bs = companyData["bs"] as? String
                    companyEntity.catchPhrase = companyData["catchPhrase"] as? String
                    companyEntity.name = companyData["name"] as? String
                    companyEntity.id =  dictionary["id"] as! Int16
                    
                }
            }
            return employeeEntity
        }
        return nil
    }
    
    private func saveInCoreDataWith(array: [[String: AnyObject]]) {
        
        _ = array.map{self.createEmployeeEntityFrom(dictionary: $0)}
        do {
            try PersistenceService.context.save()
        } catch let error {
            print(error)
        }
        
        retriveData()
        
    }
    
    
    func retriveData() {
        
        let fetchRequest: NSFetchRequest<Employee> = Employee.fetchRequest()
        
        do {
            let employeeLists = try PersistenceService.context.fetch(fetchRequest)
            self.employeeList = employeeLists
            self.tableView.reloadData()
        } catch {}
        
    }
    
    func callAPI() {
        NetworkManager.shared.getData(onSuccess: { data in
            DispatchQueue.main.async {
                do {
                    
                    let jsonResponse = try JSONSerialization.jsonObject(with:
                                                                            data, options: [])
                    
                    self.saveInCoreDataWith(array: jsonResponse as! [[String : AnyObject]])
                    
                } catch DecodingError.keyNotFound(let key, let context) {
                    Swift.print("could not find key \(key) in JSON: \(context.debugDescription)")
                } catch DecodingError.valueNotFound(let type, let context) {
                    Swift.print("could not find type \(type) in JSON: \(context.debugDescription)")
                } catch DecodingError.typeMismatch(let type, let context) {
                    Swift.print("type mismatch for type \(type) in JSON: \(context.debugDescription)")
                } catch DecodingError.dataCorrupted(let context) {
                    Swift.print("data found to be corrupted in JSON: \(context.debugDescription)")
                } catch let error as NSError {
                    NSLog("Error in read(from:ofType:) domain= \(error.domain), description= \(error.localizedDescription)")
                }
            }
        }, onFailure: { error in
            print("errordddd:",error)
        })
    }
    
    func resetAllCoreData() {
        
        // get all entities and loop over them
        let entityNames = PersistenceService.persistentContainer.managedObjectModel.entities.map({ $0.name!})
        entityNames.forEach { [weak self] entityName in
            let deleteFetch = NSFetchRequest<NSFetchRequestResult>(entityName: entityName)
            let deleteRequest = NSBatchDeleteRequest(fetchRequest: deleteFetch)
            
            do {
                try PersistenceService.context.execute(deleteRequest)
                try PersistenceService.context.save()
            } catch {
                // error
            }
        }
    }
    
    
    func userSelectedEmployee(identifier: String)-> String {
        
        let context = PersistenceService.context
        
        do {
            let fetchRequest : NSFetchRequest<Company> = Company.fetchRequest()
            fetchRequest.predicate = NSPredicate(format: "id == %@", identifier)
            let fetchedResults = try context.fetch(fetchRequest)
            if let companyName = fetchedResults.first {
                return companyName.name ?? "Invalid Name"
            } else {
                return ""
            }
        }
        catch {
            print ("fetch task failed", error)
        }
        return ""
    }
    
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}


extension HomeViewController: UITableViewDelegate, UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        if employeeList.count == 0 {
            self.tableView.setEmptyMessage("Click 'Refresh' to load the data....!")
        } else {
            self.tableView.restore()
        }
        if searching {
            return searchedEmployee.count
        } else {
            return employeeList.count
        }
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var employees = employeeList[indexPath.row]
        
        if searching {
            employees = searchedEmployee[indexPath.row]
        } else {
            employees = employeeList[indexPath.row]
        }
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath) as? EmployeeListTableViewCell else {fatalError("Unable to create cell")}
        
        
        if let idValue = employees.value(forKey: "id") as? Int16 {
            companyName =  self.userSelectedEmployee(identifier: String(idValue))
        }
        if let name = employees.value(forKeyPath: "name") as? String{
            cell.namelbl.text =  "Name : " + name
            cell.comapnyNamelbl.text = "Company : " + companyName
            
            if let profileImage = employees.value(forKeyPath: "profile_image") as? String {
                cell.profileImage.sd_setImage(with: URL(string: profileImage), placeholderImage: UIImage.init(named: "Profile"))
            } else {
                cell.profileImage.sd_setImage(with: URL(string: ""), placeholderImage: UIImage.init(named: "Profile"))
            }
        }
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 120
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        let vc = UIStoryboard(name: "Main", bundle: nil).instantiateViewController(withIdentifier: "DetailViewController_ID") as! DetailViewController
        
        var employees = employeeList[indexPath.row]
        
        if searching {
            employees = searchedEmployee[indexPath.row]
        } else {
            employees = employeeList[indexPath.row]
        }
        
        if let idValue = employees.value(forKey: "id") as? Int16 {
            vc.selectedEmployeeID = String(idValue)
        }
        if let name = employees.value(forKeyPath: "name") as? String {
            vc.name = name
        }
        if let username = employees.value(forKeyPath: "username") as? String{
            vc.userName = username
        }
        if let email = employees.value(forKeyPath: "email") as? String{
            vc.email = email
        }
        if let profile_image = employees.value(forKeyPath: "profile_image") as? String{
            vc.profile_Image = profile_image
        }
        if let phone = employees.value(forKeyPath: "phone") as? String{
            vc.phone = phone
        }
        if let website = employees.value(forKeyPath: "website") as? String
        {
            vc.website = website
        }
        
        self.navigationController?.pushViewController(vc, animated: true)
    }
    
}



extension UITableView {
    
    func setEmptyMessage(_ message: String) {
        let messageLabel = UILabel(frame: CGRect(x: 0, y: 0, width: self.bounds.size.width, height: self.bounds.size.height))
        messageLabel.text = message
        messageLabel.textColor = .black
        messageLabel.numberOfLines = 0
        messageLabel.textAlignment = .center
        messageLabel.font = UIFont(name: "TrebuchetMS", size: 15)
        messageLabel.sizeToFit()
        
        self.backgroundView = messageLabel
        self.separatorStyle = .none
    }
    
    func restore() {
        self.backgroundView = nil
        self.separatorStyle = .singleLine
    }
}



