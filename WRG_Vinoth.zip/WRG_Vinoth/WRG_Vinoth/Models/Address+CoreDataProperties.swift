//
//  Address+CoreDataProperties.swift
//  WRG_Vinoth
//
//  Created by Vinothkumar.v02 on 27/05/22.
//
//

import Foundation
import CoreData


extension Address {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Address> {
        return NSFetchRequest<Address>(entityName: "Address")
    }
    @NSManaged public var id: Int16
    @NSManaged public var zipcode: String?
    @NSManaged public var suite: String?
    @NSManaged public var street: String?
    @NSManaged public var city: String?
    @NSManaged public var employee: Employee?
    @NSManaged public var geo: Geo?

}

extension Address : Identifiable {

}
