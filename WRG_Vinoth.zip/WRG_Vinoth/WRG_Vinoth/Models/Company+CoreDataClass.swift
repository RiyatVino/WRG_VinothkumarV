//
//  Company+CoreDataClass.swift
//  WRG_Vinoth
//
//  Created by Vinothkumar.v02 on 27/05/22.
//
//

import Foundation
import CoreData

@objc(Company)
public class Company: NSManagedObject {

}
