//
//  Company+CoreDataProperties.swift
//  WRG_Vinoth
//
//  Created by Vinothkumar.v02 on 27/05/22.
//
//

import Foundation
import CoreData


extension Company {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Company> {
        return NSFetchRequest<Company>(entityName: "Company")
    }
    @NSManaged public var id: Int16
    @NSManaged public var name: String?
    @NSManaged public var catchPhrase: String?
    @NSManaged public var bs: String?
    @NSManaged public var employee: Employee?

}

extension Company : Identifiable {

}
