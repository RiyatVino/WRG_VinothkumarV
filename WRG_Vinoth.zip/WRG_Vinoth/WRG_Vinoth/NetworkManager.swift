//
//  NetworkManager.swift
//  WRG_Task
//
//  Created by Vinothkumar.v02 on 27/05/22.
//

import Foundation


final class NetworkManager: NSObject {
    
    
   
    
    static let shared = NetworkManager()
    
    func getData(onSuccess: @escaping(Foundation.Data) -> Void, onFailure: @escaping(Error) -> Void) {
        
        let url : String = "http://www.mocky.io/v2/5d565297300000680030a986"
        
        #if DEBUG
        print("URL:\(url)")
        #endif
        
        let request: NSMutableURLRequest = NSMutableURLRequest(url: NSURL(string: url)! as URL)
        request.httpMethod = "POST"

        let session = URLSession.shared

        let task = session.dataTask(with: request as URLRequest,
                                    completionHandler: {data, _, error -> Void in
                                        if(error != nil) {
                                            onFailure(error!)
                                        } else {
                                            guard let data = data else {
                                                print("API CALL FAIL:-",String(describing: error))
                                                return
                                            }
                                            let str = String(decoding: data, as: UTF8.self)
                                            let jsonData = str.data(using: .utf8)!
                                            onSuccess(jsonData)
                                        }
        })
        task.resume()
    }
}
